package com.fr.konwledge.konwledge.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.fr.konwledge.BR;

public class ObPerson extends BaseObservable {
    private String name;
    private String age;

    public ObPerson(String name, String age) {
        this.name = name;
        this.age = age;
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }

    @Bindable
    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
        notifyPropertyChanged(BR.age);
    }
}
