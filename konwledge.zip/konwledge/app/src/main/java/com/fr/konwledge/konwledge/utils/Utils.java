package com.fr.konwledge.konwledge.utils;

import android.databinding.BindingConversion;

import com.fr.konwledge.konwledge.model.Person;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public static String getName(Person person){
        return person.getName();
    }

    @BindingConversion
    public static String convertDate(Date date){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.format(date);
    }
}
