package com.fr.konwledge.konwledge.view.adapter;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.ViewGroup;


import androidx.recyclerview.widget.RecyclerView;

import com.fr.konwledge.R;
import com.fr.konwledge.databinding.ItemPersonBinding;
import com.fr.konwledge.konwledge.model.Person;

import java.util.List;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.PersonViewHolder> {

    private List<Person> mList;

    public PersonAdapter(List<Person> mList){
        this.mList = mList;
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPersonBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.item_person,parent,false);
        return new PersonViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {
        Person person = mList.get(position);
        holder.getBinding().setPerson(person);
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class PersonViewHolder extends RecyclerView.ViewHolder {
        ItemPersonBinding binding;
        public PersonViewHolder(@NonNull ViewDataBinding binding) {
            super(binding.getRoot());
            this.binding = (ItemPersonBinding) binding;
        }

        public ItemPersonBinding getBinding(){
            return binding;
        }
    }

}
