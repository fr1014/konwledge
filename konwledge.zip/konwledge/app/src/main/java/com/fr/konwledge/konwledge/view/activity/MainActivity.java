package com.fr.konwledge.konwledge.view.activity;

import android.databinding.DataBindingUtil;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.fr.konwledge.R;
import com.fr.konwledge.databinding.ActivityMainBinding;
import com.fr.konwledge.konwledge.model.Person;
import com.fr.konwledge.konwledge.view.adapter.PersonAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main);

        initRecyclerView();
    }

    private void initRecyclerView() {
        LinearLayoutManager manager = new LinearLayoutManager(MainActivity.this);
        binding.recycler.setLayoutManager(manager);
        PersonAdapter adapter = new PersonAdapter(getList());
        binding.recycler.setAdapter(adapter);
    }

    private List<Person> getList() {
        List<Person> list = new ArrayList<>();
        Person person1 = new Person("fr","20");
        Person person2 = new Person("ghl","19");
        list.add(person1);
        list.add(person2);
        return list;
    }
}
